import 'package:flutter/material.dart';

class WishlistOverviewPage extends StatelessWidget {
  const WishlistOverviewPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
