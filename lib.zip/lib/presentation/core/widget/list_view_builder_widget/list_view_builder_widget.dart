import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:library_package/presentation/core/utils/color/color_constants.dart';
import 'package:library_package/presentation/core/utils/imageUrl/image_constants.dart';
import 'package:library_package/presentation/core/utils/sizedbox/size_const.dart';
import 'package:library_package/presentation/core/widget/text_widget/text_widget.dart';

class ListViewBuilderWidget extends StatelessWidget {
  const ListViewBuilderWidget({
    super.key,
    this.list,
    this.image,
  });

  final List? list;
  final String? image;

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      itemCount: list!.length,
      shrinkWrap: true,
      physics: const BouncingScrollPhysics(),
      separatorBuilder: (context, index) {
        return const SizedBox(
          height: 16,
        );
      },
      itemBuilder: (context, index) {
        return Column(
          children: [
            Container(
              height: 70,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: kTextFieldBorderColor,
                ),
              ),
              child: Row(
                children: [
                  kappWidth20,
                  CircleAvatar(
                    radius: 17,
                    child: SvgPicture.asset(kEnglishlogo),
                  ),
                  kappWidth20,
                  TextWidget(
                    data: list![index],
                    fontSize: 14,
                    color: kPrimaryDarkTextColor,
                    inputValue: 4,
                  ),
                  const Spacer(),
                  CircleAvatar(
                    radius: 10,
                    child: SvgPicture.asset(kChecklogo),
                  ),
                  kappWidth20,
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}
