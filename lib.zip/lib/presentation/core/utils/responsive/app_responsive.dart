import 'dart:ui';
import 'package:flutter/material.dart';

double get kHeight => MediaQueryData.fromWindow(window).size.height;
double get kWidth => MediaQueryData.fromWindow(window).size.width;
